"""Utility functions for text processing and date normalization."""
import re
from datetime import datetime


def normalize_date(date_str: str) -> str:
    """
    Normalize various date formats to dd/mm/yyyy.
    
    Handles formats like:
    - "3rd March 2023"
    - "03-03-2023"
    - "March 3rd 2023"
    - "14/02/2023"
    """
    if not date_str:
        return None
    
    # Remove ordinal suffixes (st, nd, rd, th)
    date_str = re.sub(r'(\d+)(st|nd|rd|th)', r'\1', date_str)
    
    # Common date formats to try
    formats = [
        '%d/%m/%Y',
        '%d-%m-%Y',
        '%d.%m.%Y',
        '%d %B %Y',
        '%d %b %Y',
        '%B %d %Y',
        '%b %d %Y',
        '%Y-%m-%d',
        '%Y/%m/%d',
    ]
    
    for fmt in formats:
        try:
            dt = datetime.strptime(date_str.strip(), fmt)
            return dt.strftime('%d/%m/%Y')
        except ValueError:
            continue
    
    return date_str


def clean_text(text: str) -> str:
    """Clean and normalize text content."""
    if not text:
        return ""
    
    # Remove extra whitespace
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def extract_postcode(text: str) -> str:
    """Extract UK postcode from text."""
    # UK postcode pattern
    pattern = r'\b[A-Z]{1,2}\d{1,2}[A-Z]?\s?\d[A-Z]{2}\b'
    match = re.search(pattern, text, re.IGNORECASE)
    return match.group(0).upper() if match else None
