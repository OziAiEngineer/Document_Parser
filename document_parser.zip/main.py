"""Entry point for legal document extraction agent."""
import sys
import json
from pathlib import Path
from rich.console import Console
from rich.panel import Panel
from rich.json import JSON
from rich.table import Table
from agent import OllamaAgent
from validator import ExtractionValidator
from document_parser import DocumentParser


console = Console()


def main():
    """Main execution function."""
    if len(sys.argv) < 2:
        console.print("[red]Error: Please provide a document file path[/red]")
        console.print("Usage: python main.py <path_to_document>")
        console.print("\nSupported formats: .txt, .pdf, .docx")
        sys.exit(1)
    
    file_path = Path(sys.argv[1])
    
    if not file_path.exists():
        console.print(f"[red]Error: File not found: {file_path}[/red]")
        sys.exit(1)
    
    # Initialize parser
    parser = DocumentParser()
    
    # Check format support
    supported = parser.get_supported_formats()
    extension = file_path.suffix.lower().lstrip('.')
    
    if extension not in supported or not supported.get(extension):
        console.print(f"[red]Error: Format '.{extension}' is not supported or required library is missing[/red]")
        
        # Show supported formats table
        table = Table(title="Supported Formats")
        table.add_column("Format", style="cyan")
        table.add_column("Status", style="green")
        table.add_column("Required Library", style="yellow")
        
        table.add_row("TXT", "✓ Available", "Built-in")
        table.add_row(
            "PDF", 
            "✓ Available" if supported['pdf'] else "✗ Not Available",
            "pypdf (pip install pypdf)"
        )
        table.add_row(
            "DOCX", 
            "✓ Available" if supported['docx'] else "✗ Not Available",
            "python-docx (pip install python-docx)"
        )
        
        console.print(table)
        sys.exit(1)
    
    # Parse document
    console.print(f"\n[cyan]Parsing document:[/cyan] {file_path}")
    console.print(f"[dim]Format: {extension.upper()}[/dim]")
    
    try:
        document_text = parser.parse(file_path)
    except Exception as e:
        console.print(f"[red]Failed to parse document: {e}[/red]")
        sys.exit(1)
    
    console.print(f"[dim]Extracted text length: {len(document_text)} characters[/dim]\n")
    
    # Extract data using Ollama
    console.print("[cyan]Extracting data using Ollama (Ministral-3)...[/cyan]")
    agent = OllamaAgent(model="ministral-3:latest")
    
    try:
        extracted_data = agent.extract_from_document(document_text)
    except Exception as e:
        console.print(f"[red]Extraction failed: {e}[/red]")
        sys.exit(1)
    
    # Validate
    console.print("[cyan]Validating extracted data...[/cyan]\n")
    validator = ExtractionValidator()
    
    try:
        validated_model, needs_review = validator.validate(extracted_data)
    except Exception as e:
        console.print(f"[red]Validation failed: {e}[/red]")
        sys.exit(1)
    
    # Convert to dict for output
    output_data = validated_model.model_dump()
    
    # Display results
    if needs_review:
        console.print(Panel(
            "[yellow]⚠ This extraction requires human review[/yellow]\n"
            f"Missing mandatory fields: {', '.join(validated_model.missing_mandatory_fields)}",
            title="Validation Warning",
            border_style="yellow"
        ))
    else:
        console.print(Panel(
            "[green]✓ All mandatory fields extracted successfully[/green]",
            title="Validation Success",
            border_style="green"
        ))
    
    # Print JSON output
    console.print("\n[cyan]Extracted Data:[/cyan]")
    console.print(JSON(json.dumps(output_data, indent=2)))
    
    # Also print raw JSON for piping
    print("\n" + json.dumps(output_data, indent=2))


if __name__ == "__main__":
    main()
