"""Pydantic v2 models for legal document extraction schema."""
from typing import Optional
from pydantic import BaseModel, Field


class CaseInstructingParty(BaseModel):
    agency_ref: Optional[str] = None
    agency_name: Optional[str] = None
    instructor_reference: Optional[str] = None
    instructing_party: Optional[str] = None


class ClaimantDetails(BaseModel):
    title: Optional[str] = None
    forenames: Optional[str] = None
    surname: Optional[str] = None
    postcode: Optional[str] = None
    address: Optional[str] = None
    email: Optional[str] = None
    medco_reference_no: Optional[str] = None
    gender: Optional[str] = None
    date_of_birth: Optional[str] = None
    telephone_home: Optional[str] = None
    telephone_work: Optional[str] = None
    mobile: Optional[str] = None
    cnf_claim_submission_date: Optional[str] = None


class CaseStatusTracking(BaseModel):
    urn: Optional[str] = None
    status: Optional[str] = None


class AccidentAndExpert(BaseModel):
    accident_date: Optional[str] = None
    expert_name: Optional[str] = None
    source: Optional[str] = None


class MedicalRecords(BaseModel):
    records_required: Optional[bool] = None
    records_arrived: Optional[bool] = None
    arrived_date: Optional[str] = None


class SpecialInstructions(BaseModel):
    injuries_symptoms: Optional[str] = None


class LegalDocumentExtraction(BaseModel):
    case_instructing_party: CaseInstructingParty
    claimant_details: ClaimantDetails
    case_status_tracking: CaseStatusTracking
    accident_and_expert: AccidentAndExpert
    medical_records: MedicalRecords
    special_instructions: SpecialInstructions
    requires_human_review: bool = False
    missing_mandatory_fields: list[str] = Field(default_factory=list)
